public class Esterno extends Tavolo {
    private double prezzocoperto;
    
    public Esterno(int numtavola, int posto){
        super('E',numtavola,posto);
    }

    public void setPrezzo(double prezzo){
        this.prezzocoperto = prezzo;
    }

    public double getPrezzo(){
        return this.prezzocoperto;
    }
}