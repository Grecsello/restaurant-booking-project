public class Interno extends Tavolo {
    private double prezzocoperto;
    
    public Interno(int numtavola, int posto) {
        super('I',numtavola,posto);
        super.setCoperto();
    }

    public void setPrezzo(double prezzo){
        this.prezzocoperto=prezzo;
    }

    public double getPrezzo(){
        return this.prezzocoperto;
    }
}