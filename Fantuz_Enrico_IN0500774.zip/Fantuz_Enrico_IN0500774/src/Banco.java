public class Banco extends Tavolo {

    public Banco(int capacita){
        super('B',capacita);
        super.setCoperto();
    }
}